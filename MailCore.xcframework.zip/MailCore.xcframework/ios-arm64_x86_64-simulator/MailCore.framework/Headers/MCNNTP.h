#ifndef MAILCORE_MCNNTP_H

#define MAILCORE_MCNNTP_H

#include <MailCore/MCNNTPGroupInfo.h>
#include <MailCore/MCNNTPProgressCallback.h>
#include <MailCore/MCNNTPSession.h>

#endif
